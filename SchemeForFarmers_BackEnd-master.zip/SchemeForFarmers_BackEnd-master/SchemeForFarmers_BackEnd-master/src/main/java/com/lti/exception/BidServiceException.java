package com.lti.exception;

public class BidServiceException extends RuntimeException {

	public BidServiceException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public BidServiceException(String message, Throwable cause, boolean enableSuppression, boolean writableStackTrace) {
		super(message, cause, enableSuppression, writableStackTrace);
		// TODO Auto-generated constructor stub
	}

	public BidServiceException(String message, Throwable cause) {
		super(message, cause);
		// TODO Auto-generated constructor stub
	}

	public BidServiceException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	public BidServiceException(Throwable cause) {
		super(cause);
		// TODO Auto-generated constructor stub
	}

}
