package com.lti.repository;

import java.util.List;

import com.lti.entity.Bid;

public interface BidRepositary {
	
	public void save(Bid b);
	
	//public List<Bid> list= showAllBidByCrpId();

}
