package com.lti.exception;

public class TransactServiceException extends RuntimeException {

	public TransactServiceException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public TransactServiceException(String message, Throwable cause, boolean enableSuppression,
			boolean writableStackTrace) {
		super(message, cause, enableSuppression, writableStackTrace);
		// TODO Auto-generated constructor stub
	}

	public TransactServiceException(String message, Throwable cause) {
		super(message, cause);
		// TODO Auto-generated constructor stub
	}

	public TransactServiceException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	public TransactServiceException(Throwable cause) {
		super(cause);
		// TODO Auto-generated constructor stub
	}

}
